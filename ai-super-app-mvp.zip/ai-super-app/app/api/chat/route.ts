import { NextRequest, NextResponse } from "next/server";
import { chooseProvider, ProviderName } from "@/lib/router";
import { ChatMessage } from "@/lib/providers/types";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const messages = body.messages as ChatMessage[];
    const provider = (body.provider || "auto") as ProviderName;

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Messages are required." }, { status: 400 });
    }

    const safeMessages = messages.slice(-30).map(m => ({
      role: m.role,
      content: String(m.content).slice(0, 20000)
    }));

    const system: ChatMessage = {
      role: "system",
      content: "You are Nexus AI, a helpful assistant inside a multi-model AI workspace. Give accurate, practical answers. When the user asks for code, provide production-minded code and explain how to run it."
    };

    const model = chooseProvider(provider, safeMessages);
    const text = await model.generate([system, ...safeMessages]);

    return NextResponse.json({ text, provider: model.name });
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "AI request failed." },
      { status: 500 }
    );
  }
}