import "./globals.css";

export const metadata = {
  title: "Nexus AI",
  description: "One workspace for multiple AI models"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}