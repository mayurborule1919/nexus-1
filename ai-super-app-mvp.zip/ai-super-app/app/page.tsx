"use client";

import { useState } from "react";

type Message = { role: "user" | "assistant"; content: string };
type Provider = "auto" | "openai" | "anthropic" | "google";

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [provider, setProvider] = useState<Provider>("auto");
  const [loading, setLoading] = useState(false);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;

    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next, provider })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");

      setMessages([...next, { role: "assistant", content: data.text }]);
    } catch (err) {
      setMessages([
        ...next,
        { role: "assistant", content: `Error: ${err instanceof Error ? err.message : "Unknown error"}` }
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="orb" /> NEXUS AI</div>
        <button className="newBtn" onClick={() => setMessages([])}>＋ New workspace</button>
        <nav>
          <div className="navItem active">◉ AI Chat</div>
          <div className="navItem">✦ AI Studio</div>
          <div className="navItem">⌘ Code</div>
          <div className="navItem">⌕ Research</div>
          <div className="navItem">▧ Projects</div>
          <div className="navItem">⚙ Settings</div>
        </nav>
        <div className="sideFooter">Multi-model AI workspace<br/><small>Prototype v0.1</small></div>
      </aside>

      <section className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">AI ORCHESTRATOR</div>
            <h1>What do you want to create?</h1>
          </div>
          <select value={provider} onChange={e => setProvider(e.target.value as Provider)}>
            <option value="auto">Auto — Best model</option>
            <option value="openai">OpenAI</option>
            <option value="anthropic">Claude</option>
            <option value="google">Gemini</option>
          </select>
        </header>

        <div className="chat">
          {messages.length === 0 ? (
            <div className="hero">
              <div className="heroOrb">✦</div>
              <h2>One workspace.<br/><span>Every AI capability.</span></h2>
              <p>Ask a question, write code, research a topic, or create content. Nexus routes the task to the selected AI provider.</p>
              <div className="cards">
                {["Build a landing page", "Research an industry", "Write a LinkedIn campaign", "Debug my Python code"].map(x =>
                  <button key={x} onClick={() => setInput(x)}>{x}<span>→</span></button>
                )}
              </div>
            </div>
          ) : (
            <div className="messages">
              {messages.map((m, i) => (
                <div className={`message ${m.role}`} key={i}>
                  <div className="avatar">{m.role === "user" ? "You" : "AI"}</div>
                  <div className="bubble">{m.content}</div>
                </div>
              ))}
              {loading && <div className="message assistant"><div className="avatar">AI</div><div className="bubble typing">Thinking…</div></div>}
            </div>
          )}
        </div>

        <div className="composer">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Tell Nexus what you want to do…"
            rows={2}
          />
          <div className="composerBottom">
            <span>Enter to send · Shift+Enter for new line</span>
            <button onClick={send} disabled={loading || !input.trim()}>{loading ? "…" : "Send ↑"}</button>
          </div>
        </div>
      </section>
    </main>
  );
}