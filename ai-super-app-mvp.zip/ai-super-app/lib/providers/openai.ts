import OpenAI from "openai";
import { AIProvider, ChatMessage } from "./types";

export class OpenAIProvider implements AIProvider {
  name = "openai";
  private client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  async generate(messages: ChatMessage[]) {
    const response = await this.client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      input: messages.map(m => ({ role: m.role, content: m.content }))
    });
    return response.output_text;
  }
}