import Anthropic from "@anthropic-ai/sdk";
import { AIProvider, ChatMessage } from "./types";

export class AnthropicProvider implements AIProvider {
  name = "anthropic";
  private client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  async generate(messages: ChatMessage[]) {
    const system = messages.filter(m => m.role === "system").map(m => m.content).join("\n");
    const userMessages = messages.filter(m => m.role !== "system").map(m => ({
      role: m.role as "user" | "assistant",
      content: m.content
    }));
    const result = await this.client.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-4-20250514",
      max_tokens: 4096,
      ...(system ? { system } : {}),
      messages: userMessages
    });
    return result.content.map(x => x.type === "text" ? x.text : "").join("");
  }
}