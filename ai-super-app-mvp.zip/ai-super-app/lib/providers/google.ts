import { GoogleGenerativeAI } from "@google/generative-ai";
import { AIProvider, ChatMessage } from "./types";

export class GoogleProvider implements AIProvider {
  name = "google";
  private client = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY || "");

  async generate(messages: ChatMessage[]) {
    const model = this.client.getGenerativeModel({
      model: process.env.GOOGLE_MODEL || "gemini-2.5-flash"
    });
    const prompt = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join("\n\n");
    const result = await model.generateContent(prompt);
    return result.response.text();
  }
}