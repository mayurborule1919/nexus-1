export type ChatMessage = {
  role: "user" | "assistant" | "system";
  content: string;
};

export interface AIProvider {
  name: string;
  generate(messages: ChatMessage[]): Promise<string>;
}